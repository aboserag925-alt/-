# The app is a local WebView wrapper; no custom shrinking rules are required.
