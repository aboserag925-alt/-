package com.aboserag.residents

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import java.io.OutputStreamWriter
import java.nio.charset.StandardCharsets

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var pendingCsv: String? = null
    private val createDocumentRequest = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(79, 70, 229)

        webView = WebView(this)
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = false
            cacheMode = WebSettings.LOAD_NO_CACHE
            builtInZoomControls = false
            displayZoomControls = false
        }

        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AndroidBridge(), "AndroidBridge")
        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun saveCsv(filename: String, content: String) {
            pendingCsv = content
            runOnUiThread {
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "text/csv"
                    putExtra(Intent.EXTRA_TITLE, filename)
                }
                startActivityForResult(intent, createDocumentRequest)
            }
        }
    }

    @Deprecated("Deprecated in Android SDK; kept for broad compatibility with minSdk 23")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != createDocumentRequest || resultCode != RESULT_OK) {
            pendingCsv = null
            return
        }
        val uri: Uri = data?.data ?: run {
            pendingCsv = null
            return
        }
        try {
            contentResolver.openOutputStream(uri)?.use { output ->
                OutputStreamWriter(output, StandardCharsets.UTF_8).use { writer ->
                    writer.write(pendingCsv.orEmpty())
                }
            }
            Toast.makeText(this, "تم حفظ ملف CSV بنجاح", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "تعذر حفظ الملف", Toast.LENGTH_LONG).show()
        } finally {
            pendingCsv = null
        }
    }

    @Deprecated("Deprecated in Android SDK; kept for compatibility")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
